package com.example.mylibrary

data class Book(
    var title:String,
    var author:String
) {}