package com.example.mylibrary

import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class AddBookActivity : AppCompatActivity() {

    private var bookList: MutableList<Book> = mutableListOf()

    private lateinit var title: EditText
    private lateinit var author: EditText
    private lateinit var button: Button
    private var index:Int = -1
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_book)
        bookList.addAll(Books().getBooks(getSharedPreferences("pref", MODE_PRIVATE)))

        title = findViewById(R.id.editTextTitle)
        author = findViewById(R.id.editTextAuthor)
        button = findViewById(R.id.button3)
        index = intent.getIntExtra("num", -1)
        if(index >= 0){
            title.setText(bookList[index].title)
            author.setText(bookList[index].author)
            button.text = "Изменить книгу"
        }
        button.setOnClickListener {
            if(index == -1){
                Books().addBook(title.text.toString(), author.text.toString(), getSharedPreferences("pref", MODE_PRIVATE))
                title.text.clear()
                author.text.clear()
                Toast.makeText(this, "Книга добавлена!", Toast.LENGTH_SHORT).show()
                finishActivity(0)
            } else {

                if (title.text.toString().trim() != "" && author.text.toString().trim() != ""){
                    bookList[index].title = title.text.toString()
                    bookList[index].author = author.text.toString()
                    Books().saveBooks(bookList, getSharedPreferences("pref", MODE_PRIVATE))
                    title.text.clear()
                    author.text.clear()
                    Toast.makeText(this, "Книга изменена!", Toast.LENGTH_SHORT).show()
                    finishActivity(0)
                } else {
                    Toast.makeText(this, "Поля должны быть заполнены!", Toast.LENGTH_SHORT).show()
                }
            }

        }

    }
}