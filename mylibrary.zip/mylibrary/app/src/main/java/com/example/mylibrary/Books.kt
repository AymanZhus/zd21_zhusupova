package com.example.mylibrary

import android.annotation.SuppressLint
import android.content.SharedPreferences
import androidx.core.content.edit
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class Books {

    fun getBooks(preferences: SharedPreferences): MutableList<Book>{
        var json: String
        if (!preferences.contains("json")){
            return mutableListOf()
        } else {
            json = preferences.getString("json", "NOT_JSON").toString()
        }
        val tempList = Gson().fromJson<MutableList<Book>>(json, object: TypeToken<MutableList<Book>>(){}.type)
        return tempList
    }
    @SuppressLint("CommitPrefEdits")
    fun addBook(title:String, author:String, preferences: SharedPreferences){
        val book = Book(title, author)
        var temp = this.getBooks(preferences)
        temp.add(book)
        preferences.edit {
            this.putString("json", Gson().toJson(temp).toString())
        }
    }
    @SuppressLint("CommitPrefEdits")
    fun saveBooks(list: MutableList<Book>, preferences: SharedPreferences) {
        preferences.edit {
            this.putString("json", Gson().toJson(list).toString())
        }
    }

}