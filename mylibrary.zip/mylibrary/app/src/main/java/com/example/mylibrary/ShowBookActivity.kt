package com.example.mylibrary

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class ShowBookActivity : AppCompatActivity() {

    private val contactList: MutableList<Book> = mutableListOf()
    private lateinit var rv: RecyclerView
    private var indexChanged: Int = -1
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_show_book)
        Log.d("sdasdf", "Create!")
        contactList.addAll(Books().getBooks(getSharedPreferences("pref", MODE_PRIVATE)))
        val adapter = BookRVAdapter(this, contactList)
        val rvListener = object : BookRVAdapter.ItemClickListener{
            override fun onItemClick(view: View?, position: Int) {
                val intent = Intent(this@ShowBookActivity, AddBookActivity::class.java)
                intent.putExtra("num", position)
                indexChanged = position
                startActivity(intent)
                Toast.makeText(this@ShowBookActivity, "position 1: $position", Toast.LENGTH_SHORT).show()
            }
        }
        adapter.setClickListener(rvListener)
        rv = findViewById(R.id.recyclerView)
        rv.adapter = adapter
        rv.layoutManager = LinearLayoutManager(this)
    }

    override fun onResume() {
        super.onResume()
        contactList.clear()
        contactList.addAll(Books().getBooks(getSharedPreferences("pref", MODE_PRIVATE)))
        Log.d("sdasdf", "Work It!")
        if(indexChanged != -1){
            rv.adapter?.notifyItemChanged(indexChanged)
        }
    }



}